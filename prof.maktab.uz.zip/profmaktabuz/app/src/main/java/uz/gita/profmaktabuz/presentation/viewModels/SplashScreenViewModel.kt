package uz.gita.profmaktabuz.presentation.viewModels

import androidx.lifecycle.LiveData

interface SplashScreenViewModel {
    val openMainScreenLiveData : LiveData<Unit>
}