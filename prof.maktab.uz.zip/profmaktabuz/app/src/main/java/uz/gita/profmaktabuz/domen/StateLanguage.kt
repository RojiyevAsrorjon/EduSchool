package uz.gita.profmaktabuz.domen

enum class StateLanguage {
    UZ, RUS, QAR
}